# EUDA Remediation App

This Python-based application analyzes Excel EUDA files, assesses risk/complexity, and suggests or generates remediation applications using AI.

## Features
- Extract formulas/macros
- Calculate complexity, sensitivity
- Use Amazon Titan for embeddings
- Store vectors in PostgreSQL (pgvector)
- Claude (Anthropic) for explanations and remediation suggestions
- Generate documentation and PowerPoint output
